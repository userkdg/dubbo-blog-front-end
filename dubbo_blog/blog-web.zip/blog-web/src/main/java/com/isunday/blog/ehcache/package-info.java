/**
 * 
 * 测试springmvc集成net.sf.ehcache的demo
 * @author win7
 *
 */
package com.isunday.blog.ehcache;
